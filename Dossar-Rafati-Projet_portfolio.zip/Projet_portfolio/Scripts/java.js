document.querySelector('form').addEventListener('submit', function(event) {
  event.preventDefault(); // Empêche la soumission par défaut du formulaire

  const name = document.getElementById('name').value;
  const email = document.getElementById('email').value; // Corrigé ici
  const message = document.getElementById('message').value; // Ajout de la récupération du message

  alert(`Merci, ${name} ! Votre message a été envoyé.`);

  // Efface les champs du formulaire
  document.getElementById('name').value = '';
  document.getElementById('email').value = '';
  document.getElementById('message').value = '';
});

// Récupérer les éléments du DOM
const hamburgerBtn = document.getElementById('hamburger-btn');
const mobileMenu = document.getElementById('mobile-menu');



// Toggle Menu for Small Screens
// ------------------------------
const hamburger = document.getElementById("hamburger");
const menuMobile = document.getElementById("menu-mobile");

// Fonction pour basculer le menu mobile
hamburger.addEventListener("click", () => {
  menuMobile.classList.toggle("show"); // Affiche ou masque le menu
});

// Ferme le menu si un lien est cliqué
menuMobile.addEventListener("click", (event) => {
  if (event.target.tagName === "A") { // Vérifie si l'élément cliqué est un lien
    menuMobile.classList.remove("show"); // Cache le menu
  }
});


// Ferme le menu si on clique en dehors
document.addEventListener("click", (event) => {
  if (
    !menuMobile.contains(event.target) && // Si le clic est en dehors du menu
    !hamburger.contains(event.target) // Et en dehors du bouton hamburger
  ) {
    menuMobile.classList.remove("show"); // Retire la classe "show"
  }
});


// Dark Mode Toggle
const darkModeToggle = document.getElementById("dark-mode-toggle");
const body = document.body;

// Check for saved preference in localStorage
const savedMode = localStorage.getItem("darkMode");
if (savedMode === "enabled") {
  enableDarkMode();
}

darkModeToggle.addEventListener("click", () => {
  if (body.classList.contains("dark-mode")) {
    disableDarkMode();
  } else {
    enableDarkMode();
  }
});


function enableDarkMode() {
  body.classList.add("dark-mode");
  document.querySelectorAll("header, section, footer").forEach((el) => {
    el.classList.add("dark-mode");
  });
  localStorage.setItem("darkMode", "enabled");
}

function disableDarkMode() {
  body.classList.remove("dark-mode");
  document.querySelectorAll("header, section, footer").forEach((el) => {
    el.classList.remove("dark-mode");
  });
  localStorage.setItem("darkMode", "disabled");
}



